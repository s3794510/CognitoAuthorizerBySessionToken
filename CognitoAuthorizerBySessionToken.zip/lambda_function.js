const jwt = require('jsonwebtoken');
const jwkToPem = require('jwk-to-pem');
const https = require('https');

const COGNITO_POOL_URL = process.env.COGNITO_POOL_URL; // e.g., 'https://cognito-idp.<YOUR_REGION>.amazonaws.com/<YOUR_USER_POOL_ID>'
const COGNITO_POOL_PUBLIC_KEY_URL = `${COGNITO_POOL_URL}/.well-known/jwks.json`;

exports.handler = async (event) => {
    const token = event.token; // Assuming token is passed in the event

    try {
        const jwks = await getJWKS();
        const pem = jwkToPem(jwks.keys[0]); // Convert the JWK to PEM format
        const decodedToken = jwt.verify(token, pem, { algorithms: ['RS256'] });

        return { userId: decodedToken.sub };
    } catch (err) {
        console.error('Failed to decode or verify token:', err);
        throw new Error('Invalid token or unauthorized');
    }
};

function getJWKS() {
    return new Promise((resolve, reject) => {
        https.get(COGNITO_POOL_PUBLIC_KEY_URL, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                resolve(JSON.parse(data));
            });

        }).on('error', (err) => {
            reject(err);
        });
    });
}
